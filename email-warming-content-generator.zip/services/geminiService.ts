import { GoogleGenAI, Type } from "@google/genai";

// Ensure the API key is available in the environment variables
if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface EmailContent {
  subject: string;
  htmlBody: string;
}

const emailSchema = {
  type: Type.OBJECT,
  properties: {
    subject: {
      type: Type.STRING,
      description: "A short, engaging, and legitimate-looking email subject line. Avoid spam trigger words.",
    },
    htmlBody: {
      type: Type.STRING,
      description: "A clean, simple, and realistic HTML email body. It should look like a transactional or light marketing email.",
    },
  },
  required: ['subject', 'htmlBody'],
};


export const generateEmailContent = async (domain: string): Promise<EmailContent> => {
  const prompt = `
    You are an expert in email deliverability with deep knowledge of how spam filters, especially Microsoft's Exchange Online Protection (EOP), analyze email. Your primary goal is to generate email content that will be classified with a Spam Confidence Level (SCL) of 1.

    Your task is to generate a unique, high-quality, and highly realistic email for a domain warming campaign. The email must be indistinguishable from a legitimate transactional or essential business communication.

    Choose one of the following common transactional themes:
    - Order confirmation (include item details, price, and an order number).
    - Password reset request.
    - Account verification with a confirmation link or code.
    - Shipping notification with a tracking number.
    - Welcome email for a new user registration.
    - Appointment reminder with date and time.
    - Security alert (e.g., new login detected).

    **CRITICAL INSTRUCTIONS TO ACHIEVE SCL 1:**

    1.  **Subject Line:**
        - Must be concise, specific, and professional.
        - Must NOT contain any spam trigger words (e.g., "free", "!", "%", "win", "urgent", "offer").
        - Use title case or sentence case, but AVOID ALL CAPS.
        - Example: "Your Order Confirmation [Order #]", "Password Reset for Your Account".

    2.  **HTML Body:**
        - **Structure:** Generate clean, well-formatted HTML. The body should have a clear greeting, a purpose statement, the main content, a call-to-action, and a professional footer.
        - **Styling:** Use minimal inline CSS for basic styling (e.g., \`font-family: Arial, sans-serif;\`, \`color: #333;\`, \`padding: 10px;\`). Do NOT use external or <style> block CSS.
        - **Personalization:** Include realistic placeholders like \`[Customer Name]\`, \`[Order ID]\`, or \`[Username]\` to make the template appear dynamic and personalized.
        - **Content Quality:** The text must be well-written, with perfect grammar and spelling. The tone should be professional and helpful.
        - **Links:**
            - Include at least one or two links.
            - Link text must be descriptive (e.g., "View Your Order", "Reset Password"). Do NOT use "Click Here".
            - The \`href\` attribute must be a plausible, full URL related to the sender's domain. For example, if the domain is 'updates@procenat.com', a link could be \`https://procenat.com/orders/view?id=12345\`. Do not use URL shorteners.
        - **Footer:** Include a realistic footer with company contact information or an address, and a compliant unsubscribe link (e.g., \`<a href="https://[domain]/unsubscribe" style="color: #888;">Unsubscribe</a>\`).

    3.  **Sender Persona:**
        - The email's content and tone must be perfectly aligned with a legitimate business operating under the domain: "${domain}".

    4.  **Uniqueness:**
        - The generated content (subject and body) must be unique on every request. Vary sentence structure, phrasing, and even the minor details of the layout.

    Return the response ONLY in JSON format according to the provided schema. Do not include any markdown or other text outside the JSON object.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: emailSchema,
        temperature: 0.9, // Increase creativity for uniqueness
      },
    });
    
    const jsonText = response.text.trim();
    const parsedContent: EmailContent = JSON.parse(jsonText);

    if (!parsedContent.subject || !parsedContent.htmlBody) {
        throw new Error('Invalid JSON structure received from API.');
    }

    return parsedContent;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to generate content from Gemini API.");
  }
};