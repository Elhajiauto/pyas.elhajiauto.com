import React, { useState } from 'react';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';

interface ContentDisplayProps {
  title: string;
  content: string;
  isLoading: boolean;
}

const ContentDisplay: React.FC<ContentDisplayProps> = ({ title, content, isLoading }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (content) {
      navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-gray-800 shadow-lg rounded-lg h-full flex flex-col">
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <h2 className="text-lg font-semibold text-cyan-400">{title}</h2>
        <button
          onClick={handleCopy}
          className="flex items-center px-3 py-1.5 text-sm rounded-md bg-gray-700 hover:bg-gray-600 text-gray-300 disabled:opacity-50 transition-colors"
          disabled={!content || copied}
        >
          {copied ? (
            <>
              <CheckIcon />
              <span className="ml-2">Copied!</span>
            </>
          ) : (
            <>
              <ClipboardIcon />
              <span className="ml-2">Copy</span>
            </>
          )}
        </button>
      </div>
      <div className="p-4 flex-grow overflow-auto">
        {isLoading ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <span>Loading content...</span>
          </div>
        ) : content ? (
          <pre className="text-sm text-gray-300 whitespace-pre-wrap break-all">
            <code>{content}</code>
          </pre>
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <span>Content will appear here.</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default ContentDisplay;
