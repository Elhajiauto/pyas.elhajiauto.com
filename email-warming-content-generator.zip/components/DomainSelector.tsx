import React from 'react';

interface DomainSelectorProps {
  domains: string[];
  selectedDomain: string;
  onChange: (event: React.ChangeEvent<HTMLSelectElement>) => void;
}

const DomainSelector: React.FC<DomainSelectorProps> = ({ domains, selectedDomain, onChange }) => {
  return (
    <div className="w-full sm:w-auto flex-grow">
      <label htmlFor="domain-select" className="block text-sm font-medium text-gray-300 mb-1">
        Select Domain
      </label>
      <select
        id="domain-select"
        value={selectedDomain}
        onChange={onChange}
        className="block w-full pl-3 pr-10 py-2 text-base border-gray-600 bg-gray-700 text-white focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm rounded-md"
      >
        {domains.map((domain) => (
          <option key={domain} value={domain}>
            {domain}
          </option>
        ))}
      </select>
    </div>
  );
};

export default DomainSelector;
