export const DOMAINS: string[] = [
  'support@luhacovice-penzion.com',
  'updates@procenat.com',
  'mail@triadobgyn.net',
  'today@cakhasa.com',
  'reminder@hoffcobrands.com',
  'media@sewinheaven.com',
  'oceane@contibelts.com',
];
